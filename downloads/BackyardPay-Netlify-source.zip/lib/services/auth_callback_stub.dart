void clearAuthCallbackUrl() {}
